<div class="breadcrumbs " id="breadcrumbs">
    <script type="text/javascript">
        try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
    </script>

    <ul class="breadcrumb">
        <li>
            <i class="icon-home home-icon"></i>
            <a href="<?php echo base_url('Dashboard'); ?>">Dashboard</a>
        </li>

        <!-- <li>
        <a href="#">Other Pages</a>
        </li>
        <li class="active">Blank Page</li> -->
    </ul><!-- .breadcrumb -->


</div>